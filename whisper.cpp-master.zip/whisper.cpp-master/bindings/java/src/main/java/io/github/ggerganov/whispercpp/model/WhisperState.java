package io.github.ggerganov.whispercpp.model;

public class WhisperState {
}
